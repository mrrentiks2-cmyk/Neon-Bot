package app.rpbot;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StatFs;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final String START = "https://" + HOST + "/assets/www/index.html";
    static final int REQ_FILE = 1, REQ_SAVE = 3, REQ_MODEL = 4;
    static final int BG = Color.parseColor("#0b0a12");

    WebView web;
    FrameLayout root;
    ValueCallback<Uri[]> fileCb;
    final Llm llm = new Llm();
    final ExecutorService genExec = Executors.newSingleThreadExecutor();
    final ExecutorService ioExec = Executors.newCachedThreadPool();
    final Map<String, HttpURLConnection> httpConns = new ConcurrentHashMap<>();
    final Map<String, Sink> sinks = new ConcurrentHashMap<>();
    final ArrayDeque<Sink> saveQueue = new ArrayDeque<>();
    Sink saving;
    volatile boolean cancelTransfer = false;
    volatile String loadedModel = null;

    static class Sink { OutputStream out; File file; String name; String mime; }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        web = new WebView(this);
        web.setBackgroundColor(BG);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    String[] types = p.getAcceptTypes();
                    String t = (types != null && types.length == 1 && types[0] != null && types[0].contains("/")) ? types[0] : "*/*";
                    i.setType(t);
                    if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(Intent.createChooser(i, "Выберите файл"), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    cb.onReceiveValue(null);
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "RP");
        web.loadUrl(START);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__rpBack && window.__rpBack()) ? 1 : 0", r -> {
            if (!"1".equals(r)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        llm.stop();
        cancelTransfer = true;
        genExec.shutdownNow();
        ioExec.shutdownNow();
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    /* ---------- events to the page ---------- */
    void emit(JSONObject o) {
        final String js = "window.__rpEvent && window.__rpEvent(" + JSONObject.quote(o.toString()) + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    JSONObject ev(String type) {
        JSONObject o = new JSONObject();
        try { o.put("type", type); } catch (Exception ignored) { }
        return o;
    }

    void toast(String t) { runOnUiThread(() -> Toast.makeText(this, t, Toast.LENGTH_LONG).show()); }

    File modelsDir() {
        File d = getExternalFilesDir("models");
        if (d == null) d = new File(getFilesDir(), "models");
        d.mkdirs();
        return d;
    }

    String nameOf(Uri u) {
        String n = null;
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) n = c.getString(0);
        } catch (Exception ignored) { }
        if (n == null) n = u.getLastPathSegment();
        return n == null ? "model.gguf" : n;
    }

    static String safeName(String n) {
        n = n.replaceAll("[\\\\/:*?\"<>|\\u0000-\\u001f]", "_").trim();
        return n.isEmpty() ? "model.gguf" : n;
    }

    /* ---------- activity results: file chooser, model import, save-as ---------- */
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SAVE) { finishSave(res == RESULT_OK && data != null ? data.getData() : null); return; }
        if (req == REQ_MODEL) {
            if (res == RESULT_OK && data != null && data.getData() != null) importModel(data.getData());
            else { JSONObject o = ev("import"); try { o.put("state", "cancel"); } catch (Exception ignored) { } emit(o); }
            return;
        }
        if (req != REQ_FILE || fileCb == null) return;
        Uri[] out = null;
        if (res == RESULT_OK && data != null) {
            ClipData cd = data.getClipData();
            if (cd != null && cd.getItemCount() > 0) {
                out = new Uri[cd.getItemCount()];
                for (int k = 0; k < out.length; k++) out[k] = cd.getItemAt(k).getUri();
            } else if (data.getData() != null) out = new Uri[]{data.getData()};
        }
        fileCb.onReceiveValue(out);
        fileCb = null;
    }

    void importModel(Uri u) {
        final String name = safeName(nameOf(u));
        ioExec.execute(() -> {
            File dst = new File(modelsDir(), name);
            File tmp = new File(modelsDir(), name + ".part");
            long total = -1;
            try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.SIZE}, null, null, null)) {
                if (c != null && c.moveToFirst() && !c.isNull(0)) total = c.getLong(0);
            } catch (Exception ignored) { }
            cancelTransfer = false;
            try (InputStream in = getContentResolver().openInputStream(u); OutputStream out = new FileOutputStream(tmp)) {
                byte[] head = new byte[4];
                int hn = in.read(head);
                if (hn < 4 || head[0] != 'G' || head[1] != 'G' || head[2] != 'U' || head[3] != 'F') throw new Exception("Это не файл модели GGUF");
                out.write(head, 0, hn);
                copy(in, out, hn, total, "import", name);
            } catch (Exception e) {
                tmp.delete();
                JSONObject o = ev("import");
                try { o.put("state", "error"); o.put("error", e.getMessage()); } catch (Exception ignored) { }
                emit(o);
                return;
            }
            if (dst.exists()) dst.delete();
            tmp.renameTo(dst);
            JSONObject o = ev("import");
            try { o.put("state", "done"); o.put("name", name); } catch (Exception ignored) { }
            emit(o);
        });
    }

    void copy(InputStream in, OutputStream out, long done, long total, String type, String name) throws Exception {
        byte[] buf = new byte[1 << 20];
        int n;
        long last = 0;
        while ((n = in.read(buf)) > 0) {
            if (cancelTransfer) throw new Exception("Отменено");
            out.write(buf, 0, n);
            done += n;
            long now = System.currentTimeMillis();
            if (now - last > 300) {
                last = now;
                JSONObject o = ev(type);
                o.put("state", "progress"); o.put("name", name); o.put("done", done); o.put("total", total);
                emit(o);
            }
        }
    }

    /* ---------- save-as dialog ---------- */
    void nextSave() {
        if (saving != null || saveQueue.isEmpty()) return;
        saving = saveQueue.poll();
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(saving.mime);
            i.putExtra(Intent.EXTRA_TITLE, saving.name);
            startActivityForResult(i, REQ_SAVE);
        } catch (Exception e) {
            toast("Нет приложения для сохранения файлов");
            saving.file.delete();
            saving = null;
            nextSave();
        }
    }

    void finishSave(Uri target) {
        Sink k = saving;
        saving = null;
        if (k == null) return;
        if (target == null) toast("Сохранение отменено");
        else {
            try (InputStream in = new FileInputStream(k.file); OutputStream out = getContentResolver().openOutputStream(target, "wt")) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                toast("Сохранено: " + nameOf(target));
            } catch (Exception e) {
                toast("Не удалось сохранить: " + e.getMessage());
            }
        }
        k.file.delete();
        nextSave();
    }

    /* ---------- JavaScript bridge ---------- */
    class Bridge {
        @JavascriptInterface
        public String deviceInfo() {
            JSONObject o = new JSONObject();
            try {
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                o.put("ram", mi.totalMem);
                o.put("ramFree", mi.availMem);
                o.put("cores", Runtime.getRuntime().availableProcessors());
                o.put("abi", Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "");
                o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
                o.put("android", Build.VERSION.RELEASE);
                StatFs st = new StatFs(modelsDir().getAbsolutePath());
                o.put("diskFree", st.getAvailableBytes());
                String le = Llm.cpuHasDotProd() || !"arm64-v8a".equals(o.optString("abi")) ? null : "Процессор не поддерживает офлайн-ИИ";
                o.put("offlineError", le == null ? JSONObject.NULL : le);
            } catch (Exception ignored) { }
            return o.toString();
        }

        @JavascriptInterface
        public String listModels() {
            JSONArray a = new JSONArray();
            File[] fs = modelsDir().listFiles();
            if (fs != null) for (File f : fs) {
                if (!f.getName().toLowerCase().endsWith(".gguf")) continue;
                JSONObject o = new JSONObject();
                try { o.put("name", f.getName()); o.put("size", f.length()); } catch (Exception ignored) { }
                a.put(o);
            }
            return a.toString();
        }

        @JavascriptInterface
        public boolean deleteModel(String name) {
            if (name.equals(loadedModel)) { llm.unload(); loadedModel = null; }
            return new File(modelsDir(), safeName(name)).delete();
        }

        @JavascriptInterface
        public void pickModel() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(i, REQ_MODEL);
                } catch (Exception e) { toast("Нет приложения для выбора файлов"); }
            });
        }

        @JavascriptInterface
        public void cancelTransfer() { cancelTransfer = true; }

        @JavascriptInterface
        public void downloadModel(String url, String name) {
            final String fname = safeName(name);
            ioExec.execute(() -> {
                cancelTransfer = false;
                File dst = new File(modelsDir(), fname);
                File tmp = new File(modelsDir(), fname + ".part");
                HttpURLConnection c = null;
                try {
                    long have = tmp.exists() ? tmp.length() : 0;
                    String cur = url;
                    for (int hop = 0; hop < 8; hop++) {
                        c = (HttpURLConnection) new URL(cur).openConnection();
                        c.setInstanceFollowRedirects(false);
                        c.setConnectTimeout(20000);
                        c.setReadTimeout(60000);
                        c.setRequestProperty("User-Agent", "NeonRoleplay/1.0");
                        if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
                        int code = c.getResponseCode();
                        if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                            cur = new URL(new URL(cur), c.getHeaderField("Location")).toString();
                            c.disconnect();
                            continue;
                        }
                        break;
                    }
                    int code = c.getResponseCode();
                    if (code == 416) { have = 0; tmp.delete(); throw new Exception("Сервер не поддерживает докачку, начните заново"); }
                    if (code != 200 && code != 206) throw new Exception("Сервер ответил кодом " + code + (code == 401 || code == 403 ? " (нужен доступ или файл закрыт)" : code == 404 ? " (файл не найден — проверьте ссылку)" : ""));
                    boolean append = code == 206;
                    if (!append) have = 0;
                    long len = c.getContentLengthLong();
                    long total = len > 0 ? len + have : -1;
                    try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(tmp, append)) {
                        copy(in, out, have, total, "download", fname);
                    }
                    try (FileInputStream fi = new FileInputStream(tmp)) {
                        byte[] h = new byte[4];
                        if (fi.read(h) < 4 || h[0] != 'G' || h[1] != 'G' || h[2] != 'U' || h[3] != 'F') { tmp.delete(); throw new Exception("Скачанный файл — не модель GGUF (проверьте ссылку)"); }
                    }
                    if (dst.exists()) dst.delete();
                    tmp.renameTo(dst);
                    JSONObject o = ev("download");
                    o.put("state", "done"); o.put("name", fname);
                    emit(o);
                } catch (Exception e) {
                    JSONObject o = ev("download");
                    try { o.put("state", "error"); o.put("name", fname); o.put("error", e.getMessage() == null ? e.toString() : e.getMessage()); o.put("partial", tmp.exists() ? tmp.length() : 0); } catch (Exception ignored) { }
                    emit(o);
                } finally {
                    if (c != null) c.disconnect();
                }
            });
        }

        @JavascriptInterface
        public void loadModel(String name, int nCtx, int nThreads) {
            genExec.execute(() -> {
                JSONObject o = ev("model");
                try { o.put("state", "loading"); o.put("name", name); } catch (Exception ignored) { }
                emit(o);
                File f = new File(modelsDir(), safeName(name));
                String err = f.exists() ? llm.load(f.getAbsolutePath(), nCtx, nThreads) : "Файл модели не найден";
                JSONObject r = ev("model");
                try {
                    r.put("name", name);
                    if (err == null) { loadedModel = name; r.put("state", "loaded"); r.put("info", new JSONObject(llm.info())); }
                    else { loadedModel = null; r.put("state", "error"); r.put("error", err); }
                } catch (Exception ignored) { }
                emit(r);
            });
        }

        @JavascriptInterface
        public void unloadModel() {
            genExec.execute(() -> {
                llm.unload();
                loadedModel = null;
                JSONObject r = ev("model");
                try { r.put("state", "unloaded"); } catch (Exception ignored) { }
                emit(r);
            });
        }

        @JavascriptInterface
        public String loadedModel() { return loadedModel == null ? "" : loadedModel; }

        @JavascriptInterface
        public void generate(String json) {
            genExec.execute(() -> {
                String id = "";
                try {
                    JSONObject q = new JSONObject(json);
                    id = q.optString("id");
                    final String gid = id;
                    JSONArray ms = q.getJSONArray("messages");
                    String[] roles = new String[ms.length()], contents = new String[ms.length()];
                    for (int i = 0; i < ms.length(); i++) { roles[i] = ms.getJSONObject(i).getString("role"); contents[i] = ms.getJSONObject(i).getString("content"); }
                    JSONArray st = q.optJSONArray("stops");
                    String[] stops = new String[st == null ? 0 : st.length()];
                    for (int i = 0; i < stops.length; i++) stops[i] = st.getString(i);
                    runOnUiThread(() -> getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON));
                    String res = llm.generate(roles, contents, q.optInt("maxTokens", 300), (float) q.optDouble("temp", 0.8),
                            (float) q.optDouble("topP", 0.95), (float) q.optDouble("minP", 0.05), q.optInt("topK", 40),
                            (float) q.optDouble("rep", 1.1), stops, q.optString("template", ""), text -> {
                                JSONObject o = ev("gen");
                                try { o.put("id", gid); o.put("text", text); } catch (Exception ignored) { }
                                emit(o);
                            });
                    JSONObject o = ev("gen_done");
                    o.put("id", id);
                    o.put("result", new JSONObject(res));
                    emit(o);
                } catch (Throwable e) {
                    JSONObject o = ev("gen_done");
                    try { o.put("id", id); o.put("result", new JSONObject().put("status", -9).put("error", String.valueOf(e.getMessage()))); } catch (Exception ignored) { }
                    emit(o);
                } finally {
                    runOnUiThread(() -> getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON));
                }
            });
        }

        @JavascriptInterface
        public void stopGen() { llm.stop(); }

        @JavascriptInterface
        public int countTokens(String text) { return llm.countTokens(text); }

        /* streaming HTTP for online AI providers (no CORS limits) */
        @JavascriptInterface
        public void http(String id, String method, String url, String headersJson, String body) {
            ioExec.execute(() -> {
                HttpURLConnection c = null;
                int code = 0;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    httpConns.put(id, c);
                    c.setRequestMethod(method);
                    c.setConnectTimeout(30000);
                    c.setReadTimeout(180000);
                    JSONObject hs = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                    for (Iterator<String> it = hs.keys(); it.hasNext(); ) { String k = it.next(); c.setRequestProperty(k, hs.getString(k)); }
                    if (body != null && !body.isEmpty()) {
                        c.setDoOutput(true);
                        byte[] b = body.getBytes(StandardCharsets.UTF_8);
                        c.setFixedLengthStreamingMode(b.length);
                        try (OutputStream os = c.getOutputStream()) { os.write(b); }
                    }
                    code = c.getResponseCode();
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    if (in != null) {
                        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                            StringBuilder sb = new StringBuilder();
                            long last = System.currentTimeMillis();
                            String line;
                            while ((line = r.readLine()) != null) {
                                sb.append(line).append('\n');
                                long now = System.currentTimeMillis();
                                if (now - last > 60 || sb.length() > 4000) {
                                    JSONObject o = ev("http"); o.put("id", id); o.put("status", code); o.put("chunk", sb.toString());
                                    emit(o); sb.setLength(0); last = now;
                                }
                            }
                            if (sb.length() > 0) { JSONObject o = ev("http"); o.put("id", id); o.put("status", code); o.put("chunk", sb.toString()); emit(o); }
                        }
                    }
                    JSONObject o = ev("http_done"); o.put("id", id); o.put("status", code);
                    emit(o);
                } catch (Exception e) {
                    JSONObject o = ev("http_done");
                    try { o.put("id", id); o.put("status", code); o.put("error", e.getMessage() == null ? e.toString() : e.getMessage()); } catch (Exception ignored) { }
                    emit(o);
                } finally {
                    httpConns.remove(id);
                    if (c != null) c.disconnect();
                }
            });
        }

        @JavascriptInterface
        public void httpCancel(String id) {
            HttpURLConnection c = httpConns.remove(id);
            if (c != null) ioExec.execute(c::disconnect);
        }

        /* saving exported files through the system "Save as" dialog */
        @JavascriptInterface
        public String begin(String name, String mime) {
            try {
                Sink k = new Sink();
                k.name = safeName(name);
                k.mime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                File dir = new File(getCacheDir(), "out");
                dir.mkdirs();
                k.file = new File(dir, UUID.randomUUID().toString());
                k.out = new FileOutputStream(k.file);
                String id = UUID.randomUUID().toString();
                sinks.put(id, k);
                return id;
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public boolean append(String id, String b64) {
            Sink k = sinks.get(id);
            if (k == null) return false;
            try { k.out.write(Base64.decode(b64, Base64.DEFAULT)); return true; } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public String finish(String id) {
            final Sink k = sinks.remove(id);
            if (k == null) return "";
            try { k.out.close(); } catch (Exception e) { return ""; }
            runOnUiThread(() -> { saveQueue.add(k); nextSave(); });
            return "ok";
        }
    }
}
