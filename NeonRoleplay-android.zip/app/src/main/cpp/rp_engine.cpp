#include "rp_engine.h"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <thread>

#include "llama.h"

static double now_ms() {
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

static std::string json_esc(const std::string &s) {
    std::string o;
    for (unsigned char c : s) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default:
                if (c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; }
                else o += (char)c;
        }
    }
    return o;
}

// length of the longest prefix of s that ends on a complete UTF-8 sequence
static size_t utf8_complete(const std::string &s) {
    size_t n = s.size();
    if (!n) return 0;
    size_t i = n;
    int back = 0;
    while (i > 0 && back < 4) {
        unsigned char c = (unsigned char)s[i - 1];
        if ((c & 0xC0) != 0x80) {  // lead byte or ASCII
            int need = c < 0x80 ? 1 : (c >> 5) == 0x6 ? 2 : (c >> 4) == 0xE ? 3 : (c >> 3) == 0x1E ? 4 : 1;
            return (n - (i - 1) >= (size_t)need) ? n : i - 1;
        }
        --i; ++back;
    }
    return n;
}

static bool g_backend = false;

RpEngine::~RpEngine() { unload(); }

void RpEngine::unload() {
    std::lock_guard<std::mutex> lk(mu_);
    if (ctx_) { llama_free(ctx_); ctx_ = nullptr; }
    if (model_) { llama_model_free(model_); model_ = nullptr; }
    vocab_ = nullptr;
    cache_.clear();
}

bool RpEngine::load(const std::string &path, int n_ctx, int n_threads, std::string &err) {
    unload();
    std::lock_guard<std::mutex> lk(mu_);
    if (!g_backend) {
        llama_log_set([](enum ggml_log_level level, const char *text, void *) {
            if (level >= GGML_LOG_LEVEL_ERROR) fprintf(stderr, "%s", text);
        }, nullptr);
        llama_backend_init();
        g_backend = true;
    }
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    model_ = llama_model_load_from_file(path.c_str(), mp);
    if (!model_) { err = "Не удалось загрузить модель (файл повреждён или формат не поддерживается)"; return false; }
    vocab_ = llama_model_get_vocab(model_);
    int train = llama_model_n_ctx_train(model_);
    if (n_ctx <= 0) n_ctx = 4096;
    if (train > 0 && n_ctx > train) n_ctx = train;
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t)n_ctx;
    cp.n_batch = (uint32_t)n_batch_;
    cp.n_ubatch = (uint32_t)n_batch_;
    int hw = (int)std::thread::hardware_concurrency();
    if (n_threads <= 0) n_threads = std::max(1, std::min(4, hw > 0 ? hw : 4));
    cp.n_threads = n_threads;
    cp.n_threads_batch = n_threads;
    ctx_ = llama_init_from_model(model_, cp);
    if (!ctx_) {
        llama_model_free(model_); model_ = nullptr; vocab_ = nullptr;
        err = "Недостаточно памяти для этой модели. Уменьшите размер контекста или выберите модель поменьше.";
        return false;
    }
    n_ctx_ = (int)llama_n_ctx(ctx_);
    path_ = path;
    cache_.clear();
    const char *t = llama_model_chat_template(model_, nullptr);
    used_tmpl_ = t ? t : "";
    return true;
}

std::string RpEngine::info() const {
    std::lock_guard<std::mutex> lk(mu_);
    if (!model_) return "{\"loaded\":false}";
    char desc[256] = {0};
    llama_model_desc(model_, desc, sizeof desc);
    char name[256] = {0};
    llama_model_meta_val_str(model_, "general.name", name, sizeof name);
    std::string o = "{\"loaded\":true";
    o += ",\"desc\":\"" + json_esc(desc) + "\"";
    o += ",\"name\":\"" + json_esc(name) + "\"";
    o += ",\"params\":" + std::to_string((unsigned long long)llama_model_n_params(model_));
    o += ",\"size\":" + std::to_string((unsigned long long)llama_model_size(model_));
    o += ",\"n_ctx\":" + std::to_string(n_ctx_);
    o += ",\"n_ctx_train\":" + std::to_string(llama_model_n_ctx_train(model_));
    o += ",\"has_template\":" + std::string(used_tmpl_.empty() ? "false" : "true");
    o += "}";
    return o;
}

std::vector<int> RpEngine::tokenize(const std::string &text, bool add_special) const {
    int n = -llama_tokenize(vocab_, text.c_str(), (int32_t)text.size(), nullptr, 0, add_special, true);
    if (n <= 0) return {};
    std::vector<llama_token> toks(n);
    int r = llama_tokenize(vocab_, text.c_str(), (int32_t)text.size(), toks.data(), n, add_special, true);
    if (r < 0) return {};
    toks.resize(r);
    return std::vector<int>(toks.begin(), toks.end());
}

int RpEngine::count_tokens(const std::string &text) const {
    std::lock_guard<std::mutex> lk(mu_);
    if (!vocab_) return (int)(text.size() / 3);
    return (int)tokenize(text, false).size();
}

std::string RpEngine::format(const std::vector<std::pair<std::string, std::string>> &messages, const std::string &tmpl_in, bool &ok) const {
    std::vector<llama_chat_message> msgs;
    msgs.reserve(messages.size());
    size_t total = 0;
    for (auto &m : messages) { msgs.push_back({m.first.c_str(), m.second.c_str()}); total += m.second.size() + 64; }
    std::vector<std::string> candidates;
    if (!tmpl_in.empty()) candidates.push_back(tmpl_in);
    if (!used_tmpl_.empty()) candidates.push_back(used_tmpl_);
    candidates.push_back("chatml");
    for (auto &t : candidates) {
        std::vector<char> buf(total * 2 + 1024);
        int n = llama_chat_apply_template(t.c_str(), msgs.data(), msgs.size(), true, buf.data(), (int32_t)buf.size());
        if (n > (int)buf.size()) { buf.resize(n + 16); n = llama_chat_apply_template(t.c_str(), msgs.data(), msgs.size(), true, buf.data(), (int32_t)buf.size()); }
        if (n >= 0) { ok = true; return std::string(buf.data(), n); }
    }
    ok = false;
    return "";
}

RpGenResult RpEngine::generate(const std::vector<std::pair<std::string, std::string>> &messages_in, const RpGenParams &p,
                               const std::function<void(const std::string &)> &on_text) {
    std::lock_guard<std::mutex> lk(mu_);
    RpGenResult res;
    stop_ = false;
    if (!ctx_) { res.status = -1; res.error = "Модель не загружена"; return res; }

    // ---- build prompt, dropping the oldest turns until it fits the context ----
    auto messages = messages_in;
    int n_predict = std::max(16, std::min(p.n_predict, n_ctx_ / 2));
    int budget = n_ctx_ - n_predict - 8;
    std::vector<int> tokens;
    bool add_bos = true;
    for (int guard = 0; guard < 1000; guard++) {
        bool ok = false;
        std::string prompt = format(messages, p.tmpl, ok);
        if (!ok) { res.status = -2; res.error = "Не удалось применить шаблон чата"; return res; }
        tokens = tokenize(prompt, add_bos);
        if ((int)tokens.size() <= budget) break;
        // find the first non-system message that is not the last one
        size_t first = 0;
        while (first < messages.size() && messages[first].first == "system") first++;
        if (first + 1 >= messages.size()) {  // only one turn left: hard-trim tokens from the front of it
            int keep = budget;
            tokens.erase(tokens.begin() + std::min<size_t>(tokens.size(), 1), tokens.begin() + (tokens.size() - keep + 1));
            break;
        }
        messages.erase(messages.begin() + first);
        res.dropped++;
    }
    if (tokens.empty()) { res.status = -3; res.error = "Пустой запрос"; return res; }
    res.n_prompt = (int)tokens.size();

    // ---- reuse the KV cache for the common prefix ----
    llama_memory_t mem = llama_get_memory(ctx_);
    size_t n_keep = 0;
    while (n_keep < cache_.size() && n_keep < tokens.size() && cache_[n_keep] == tokens[n_keep]) n_keep++;
    if (n_keep == tokens.size()) n_keep--;  // need at least one token to get fresh logits
    if (n_keep < cache_.size()) {
        if (!llama_memory_seq_rm(mem, 0, (llama_pos)n_keep, -1)) {
            llama_memory_clear(mem, true);
            n_keep = 0;
        }
        cache_.resize(n_keep);
    }
    res.n_reused = (int)n_keep;

    double t0 = now_ms();
    for (size_t i = n_keep; i < tokens.size(); i += n_batch_) {
        if (stop_) { res.status = 1; return res; }
        int n = (int)std::min<size_t>(n_batch_, tokens.size() - i);
        std::vector<llama_token> chunk(tokens.begin() + i, tokens.begin() + i + n);
        llama_batch b = llama_batch_get_one(chunk.data(), n);
        int rc = llama_decode(ctx_, b);
        if (rc != 0) {
            llama_memory_clear(mem, true); cache_.clear();
            res.status = -4; res.error = "Ошибка обработки запроса (код " + std::to_string(rc) + ")";
            return res;
        }
        cache_.insert(cache_.end(), chunk.begin(), chunk.end());
    }
    res.prompt_ms = now_ms() - t0;

    // ---- sampler ----
    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(p.top_k > 0 ? p.top_k : 100));
    if (p.repeat_penalty > 1.0f && p.repeat_last_n != 0)
        llama_sampler_chain_add(smpl, llama_sampler_init_penalties(llama_vocab_n_tokens(vocab_), p.repeat_last_n, p.repeat_penalty, 0.0f, 0.0f));
    if (p.top_p < 1.0f) llama_sampler_chain_add(smpl, llama_sampler_init_top_p(p.top_p, 1));
    if (p.min_p > 0.0f) llama_sampler_chain_add(smpl, llama_sampler_init_min_p(p.min_p, 1));
    if (p.temp <= 0.0f) llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    else {
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(p.temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }
    // let the repetition penalty see the recent conversation
    size_t from = tokens.size() > 256 ? tokens.size() - 256 : 0;
    for (size_t i = from; i < tokens.size(); i++) llama_sampler_accept(smpl, tokens[i]);

    // ---- generation ----
    size_t hold = 0;
    for (auto &s : p.stops) hold = std::max(hold, s.size());
    std::string out, pending;  // out = all text; pending = bytes not yet emitted
    size_t emitted = 0;
    double t1 = now_ms();
    char piece[512];
    for (int i = 0; i < n_predict; i++) {
        if (stop_) { res.status = 1; break; }
        llama_token tok = llama_sampler_sample(smpl, ctx_, -1);
        if (llama_vocab_is_eog(vocab_, tok)) break;
        int n = llama_token_to_piece(vocab_, tok, piece, sizeof piece, 0, false);
        if (n < 0) n = 0;
        out.append(piece, n);
        res.n_gen++;
        // stop strings
        bool hit = false;
        for (auto &s : p.stops) {
            if (s.empty()) continue;
            size_t pos = out.find(s, emitted > s.size() ? emitted - s.size() : 0);
            if (pos != std::string::npos) { out.resize(pos); hit = true; break; }
        }
        // emit everything except a tail that could still become a stop string
        size_t limit = hit ? out.size() : (out.size() > hold ? out.size() - (hold ? hold - 1 : 0) : 0);
        if (limit > emitted) {
            std::string chunk = out.substr(emitted, limit - emitted);
            size_t ok = utf8_complete(chunk);
            if (ok > 0) { on_text(chunk.substr(0, ok)); emitted += ok; }
        }
        if (hit) break;
        if ((int)cache_.size() + 1 >= n_ctx_) { res.status = 2; break; }
        llama_token t = tok;
        llama_batch b = llama_batch_get_one(&t, 1);
        if (llama_decode(ctx_, b) != 0) { res.status = 2; break; }
        cache_.push_back(tok);
    }
    if (emitted < out.size()) {
        std::string rest = out.substr(emitted);
        size_t ok = utf8_complete(rest);
        if (ok > 0) on_text(rest.substr(0, ok));
    }
    res.gen_ms = now_ms() - t1;
    res.text = out;
    llama_sampler_free(smpl);
    return res;
}
