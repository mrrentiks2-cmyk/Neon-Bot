// JNI glue: app.rpbot.Llm <-> RpEngine
#include <jni.h>
#include <string>
#include <vector>
#include "rp_engine.h"

static std::string jstr(JNIEnv *env, jstring s) {
    if (!s) return "";
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string r(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}
// Java strings -> real UTF-8 (GetStringUTFChars gives "modified UTF-8" which breaks emoji)
static std::string jutf8(JNIEnv *env, jstring s) {
    if (!s) return "";
    jclass sc = env->FindClass("java/lang/String");
    jmethodID gb = env->GetMethodID(sc, "getBytes", "(Ljava/lang/String;)[B");
    jstring enc = env->NewStringUTF("UTF-8");
    jbyteArray arr = (jbyteArray)env->CallObjectMethod(s, gb, enc);
    env->DeleteLocalRef(enc);
    env->DeleteLocalRef(sc);
    if (!arr) return "";
    jsize n = env->GetArrayLength(arr);
    std::string out(n, '\0');
    env->GetByteArrayRegion(arr, 0, n, (jbyte *)out.data());
    env->DeleteLocalRef(arr);
    return out;
}
static jstring utf8_to_j(JNIEnv *env, const std::string &s) {
    jbyteArray arr = env->NewByteArray((jsize)s.size());
    env->SetByteArrayRegion(arr, 0, (jsize)s.size(), (const jbyte *)s.data());
    jclass sc = env->FindClass("java/lang/String");
    jmethodID ctor = env->GetMethodID(sc, "<init>", "([BLjava/lang/String;)V");
    jstring enc = env->NewStringUTF("UTF-8");
    jstring r = (jstring)env->NewObject(sc, ctor, arr, enc);
    env->DeleteLocalRef(enc);
    env->DeleteLocalRef(arr);
    env->DeleteLocalRef(sc);
    return r;
}

extern "C" {

JNIEXPORT jlong JNICALL Java_app_rpbot_Llm_nativeCreate(JNIEnv *, jclass) { return (jlong) new RpEngine(); }

JNIEXPORT void JNICALL Java_app_rpbot_Llm_nativeDestroy(JNIEnv *, jclass, jlong h) { delete (RpEngine *)h; }

JNIEXPORT jstring JNICALL Java_app_rpbot_Llm_nativeLoad(JNIEnv *env, jclass, jlong h, jstring path, jint nCtx, jint nThreads) {
    std::string err;
    bool ok = ((RpEngine *)h)->load(jstr(env, path), nCtx, nThreads, err);
    return ok ? nullptr : utf8_to_j(env, err);
}

JNIEXPORT void JNICALL Java_app_rpbot_Llm_nativeUnload(JNIEnv *, jclass, jlong h) { ((RpEngine *)h)->unload(); }

JNIEXPORT jstring JNICALL Java_app_rpbot_Llm_nativeInfo(JNIEnv *env, jclass, jlong h) { return utf8_to_j(env, ((RpEngine *)h)->info()); }

JNIEXPORT void JNICALL Java_app_rpbot_Llm_nativeStop(JNIEnv *, jclass, jlong h) { ((RpEngine *)h)->request_stop(); }

JNIEXPORT jint JNICALL Java_app_rpbot_Llm_nativeCountTokens(JNIEnv *env, jclass, jlong h, jstring text) { return ((RpEngine *)h)->count_tokens(jutf8(env, text)); }

JNIEXPORT jstring JNICALL Java_app_rpbot_Llm_nativeGenerate(JNIEnv *env, jclass, jlong h, jobjectArray roles, jobjectArray contents,
        jint nPredict, jfloat temp, jfloat topP, jfloat minP, jint topK, jfloat repeatPenalty, jobjectArray stops, jstring tmpl, jobject cb) {
    std::vector<std::pair<std::string, std::string>> msgs;
    jsize n = env->GetArrayLength(roles);
    for (jsize i = 0; i < n; i++) {
        jstring r = (jstring)env->GetObjectArrayElement(roles, i);
        jstring c = (jstring)env->GetObjectArrayElement(contents, i);
        msgs.emplace_back(jstr(env, r), jutf8(env, c));
        env->DeleteLocalRef(r);
        env->DeleteLocalRef(c);
    }
    RpGenParams p;
    p.n_predict = nPredict; p.temp = temp; p.top_p = topP; p.min_p = minP; p.top_k = topK; p.repeat_penalty = repeatPenalty;
    if (stops) {
        jsize ns = env->GetArrayLength(stops);
        for (jsize i = 0; i < ns; i++) { jstring s = (jstring)env->GetObjectArrayElement(stops, i); std::string v = jutf8(env, s); if (!v.empty()) p.stops.push_back(v); env->DeleteLocalRef(s); }
    }
    p.tmpl = jstr(env, tmpl);
    jclass cls = env->GetObjectClass(cb);
    jmethodID onText = env->GetMethodID(cls, "onText", "(Ljava/lang/String;)V");
    RpGenResult res = ((RpEngine *)h)->generate(msgs, p, [&](const std::string &chunk) {
        jstring js = utf8_to_j(env, chunk);
        env->CallVoidMethod(cb, onText, js);
        env->DeleteLocalRef(js);
        if (env->ExceptionCheck()) env->ExceptionClear();
    });
    env->DeleteLocalRef(cls);
    std::string j = "{\"status\":" + std::to_string(res.status) + ",\"n_prompt\":" + std::to_string(res.n_prompt) + ",\"n_reused\":" + std::to_string(res.n_reused) +
                    ",\"n_gen\":" + std::to_string(res.n_gen) + ",\"dropped\":" + std::to_string(res.dropped) + ",\"prompt_ms\":" + std::to_string((long long)res.prompt_ms) +
                    ",\"gen_ms\":" + std::to_string((long long)res.gen_ms) + ",\"error\":\"";
    for (char ch : res.error) { if (ch == '"' || ch == '\\') j += '\\'; if (ch == '\n') { j += "\\n"; continue; } j += ch; }
    j += "\"}";
    return utf8_to_j(env, j);
}

}  // extern "C"
