// Offline LLM engine for the roleplay app (thin wrapper around llama.cpp)
#pragma once
#include <atomic>
#include <functional>
#include <mutex>
#include <string>
#include <vector>

struct llama_model;
struct llama_context;
struct llama_vocab;

struct RpGenParams {
    int n_predict = 300;
    float temp = 0.8f;
    float top_p = 0.95f;
    float min_p = 0.05f;
    int top_k = 40;
    float repeat_penalty = 1.1f;
    int repeat_last_n = 256;
    std::vector<std::string> stops;
    std::string tmpl;  // empty = use model's own template
};

struct RpGenResult {
    int status = 0;          // 0 done, 1 stopped by user, 2 context full, <0 error
    int n_prompt = 0;        // prompt tokens
    int n_reused = 0;        // prompt tokens reused from cache
    int n_gen = 0;           // generated tokens
    int dropped = 0;         // old messages dropped to fit the context
    double prompt_ms = 0, gen_ms = 0;
    std::string error;
    std::string text;        // full generated text (after stop-string trimming)
};

class RpEngine {
public:
    ~RpEngine();
    bool load(const std::string &path, int n_ctx, int n_threads, std::string &err);
    void unload();
    bool loaded() const { return ctx_ != nullptr; }
    std::string info() const;  // JSON
    // messages: (role, content). on_text receives complete UTF-8 chunks.
    RpGenResult generate(const std::vector<std::pair<std::string, std::string>> &messages, const RpGenParams &p,
                         const std::function<void(const std::string &)> &on_text);
    void request_stop() { stop_ = true; }
    int count_tokens(const std::string &text) const;

private:
    std::string format(const std::vector<std::pair<std::string, std::string>> &messages, const std::string &tmpl, bool &ok) const;
    std::vector<int> tokenize(const std::string &text, bool add_special) const;
    llama_model *model_ = nullptr;
    llama_context *ctx_ = nullptr;
    const llama_vocab *vocab_ = nullptr;
    std::vector<int> cache_;  // tokens currently stored in the KV cache (sequence 0)
    std::atomic<bool> stop_{false};
    int n_ctx_ = 0, n_batch_ = 512;
    std::string path_, used_tmpl_;
    mutable std::mutex mu_;
};
